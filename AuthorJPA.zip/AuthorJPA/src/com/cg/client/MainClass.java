package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		
		Author author1 = new Author();
		author1.setFirstName("Surya");
		author1.setMiddleName("Murugesan");
		author1.setLastName("Reddy");
		author1.setPhoneNo(9655032993l);
		manager.persist(author1);
		
		Author author2=new Author();
		author2.setFirstName("Saravana");
		author2.setMiddleName("Bhavan");
		author2.setLastName("Thirumavalavan");
		author2.setPhoneNo(9874563210l);
		manager.persist(author2);
		
		Author author3=new Author();
		author3.setFirstName("Sree");
		author3.setMiddleName("Sindhu");
		author3.setLastName("Kashetty");
		author3.setPhoneNo(9874585621l);
		manager.persist(author3);
		
		Author author4=new Author();
		author4.setFirstName("Sushma");
		author4.setMiddleName("Mattam");
		author4.setLastName("Virat");
		author4.setPhoneNo(7896547890l);
		manager.persist(author4);
		
		Author author5=new Author();
		author5.setFirstName("John");
		author5.setMiddleName("Cena");
		author5.setLastName("Don");
		author5.setPhoneNo(7896547890l);
		manager.persist(author5);
		
		manager.close();
		System.out.println("added to the database");
		manager.getTransaction().commit();
		factory.close();
		
		

	}

}
