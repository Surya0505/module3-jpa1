package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class DeleteClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager=factory.createEntityManager();
		manager.getTransaction().begin();
		
		Author author=manager.find(Author.class, 14);
		manager.remove(author);
		
		manager.close();
		System.out.println("1 row deleted");
		manager.getTransaction().commit();
		factory.close();

	}

}
