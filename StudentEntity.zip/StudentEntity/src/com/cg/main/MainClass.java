package com.cg.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.StudentEntity;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		StudentEntity entity = new StudentEntity();
		entity.setStudentName("Surya");
		entity.setMarks(495);
		
		manager.persist(entity);
		
		manager.close();
		System.out.println("Student Added");
		manager.getTransaction().commit();
		factory.close();

	}

}
