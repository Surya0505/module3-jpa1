package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Employee;

public class MainClass {
	
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		Employee employee = new Employee();
		employee.setEmpName("Surya");
		employee.setEmpSal(30000);
		
		manager.persist(employee);
		Employee employee1 = new Employee();
		employee1.setEmpName("Vidhya");
		employee1.setEmpSal(25000);
		
		manager.persist(employee1);
		Employee employee2 = new Employee();
		employee2.setEmpName("Joanna");
		employee2.setEmpSal(27000);
		
		manager.persist(employee2);
		
		manager.getTransaction().commit();
		manager.close();
		System.out.println("Added employee");
		
		factory.close();
	}
}
