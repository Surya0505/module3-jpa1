package com.cg.main.mobile;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.mobile.Mobile;

public class Update {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		
		Mobile mobile = manager.find(Mobile.class, 213);
		System.out.println("Original=" +mobile);
		
		mobile.setMobileName(mobile.getMobileName()+" Xiaomi");
		manager.merge(mobile);
		manager.getTransaction().commit();
		manager.close();
		System.out.println("Updated");
		factory.close();
	}

}
